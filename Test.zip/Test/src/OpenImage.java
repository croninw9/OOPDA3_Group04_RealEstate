
import java.awt.*;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;

public class OpenImage{
	private JFrame frame;
	private JButton button;
	private JPanel bPanel;
	private ImagePanel imagePanel;
	private JLabel image;
    private OFImage currentImage;
    private JLabel filenameLabel;
    private JLabel statusLabel;
	private static JFileChooser fileChooser = new JFileChooser(System.getProperty("user.dir"));
	
   public OpenImage() {
	   frame = new JFrame();
	   button = new JButton("Press this");
	   button.addActionListener(e -> openFile());
	   imagePanel = new ImagePanel();
	   bPanel = new JPanel();
	   bPanel.add(button);
	   frame.add(bPanel, BorderLayout.WEST);
	   frame.add(imagePanel, BorderLayout.EAST);
	   frame.pack();
	   frame.setVisible(true);
   }
   
   private void openFile()
   {
       int returnVal = fileChooser.showOpenDialog(frame); 

       if(returnVal != JFileChooser.APPROVE_OPTION) {
           return;  // cancelled
       }
       File selectedFile = fileChooser.getSelectedFile();
       currentImage = ImageFileManager.loadImage(selectedFile);
       
       if(currentImage == null) {   // image file was not a valid image
           JOptionPane.showMessageDialog(frame,
                   "The file was not in a recognized image file format.",
                   "Image Load Error",
                   JOptionPane.ERROR_MESSAGE);
           return;
       }

       imagePanel.setImage(currentImage);
       showFilename(selectedFile.getPath());
       System.out.println(selectedFile.getPath());
       showStatus("File loaded.");
       frame.pack();
   }
   private void showFilename(String filename)
   {
       if(filename == null) {
           filenameLabel.setText("No file displayed.");
       }
       else {
           filenameLabel.setText("File: " + filename);
       }
   }
   private void showStatus(String text)
   {
       statusLabel.setText(text);
   }
   public static BufferedImage loadImage(File imageFile)
   {
       try {
           BufferedImage image = ImageIO.read(imageFile);
           if(image == null || (image.getWidth(null) < 0)) {
               // we could not load the image - probably invalid file format
               return null;
           }
           return image;
       }
       catch(IOException exc) {
           return null;
       }
   }
}